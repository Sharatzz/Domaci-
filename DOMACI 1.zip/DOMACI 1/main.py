import math
#######DOMACI 1############
# RADOVAN SARAC



# 1.

def povrsina_obim_pravougaonika():

    a = int(input('Unesite stranicu a: '))
    b = int(input('Unesite stranicu b: '))

    povrsina = a*b
    obim = 2*(a+b)

    return povrsina, obim

# 2.
def resenje_kvadratne_jednacine():

    a = int(input('Unesite  a: '))
    b = int(input('Unesite  b: '))
    c = int(input('Unesite  c: '))

    x1 = (-b + math.sqrt((b**2)-4*a*c))/2*a
    x2 = (-b - math.sqrt((b ** 2) - 4 * a * c)) / 2 * a

    return x1, x2

# 3.
def razlika_kvadrata():
    a = int(input('Unesite broj 1: '))
    b = int(input('Unesite broj 2: '))

    return (a**2)-(b**2)

# 4.
def koliko_pretrci_sportista():

    d =  int(input('Unesite d: '))
    s = int(input('Unesite s: '))

    return 4*2*(d+s)

# 5.
def povrsina_u_kvdrt_cm():
    sirina = int(input('Unesite sirinu: '))
    duzina = int(input('Unesite duzinu: '))

    povrsina = sirina * duzina

    return povrsina * 0.01

#6.
def kvadrat_trinoma():

    a = int(input('Unesite  a: '))
    b = int(input('Unesite  b: '))
    c = int(input('Unesite  c: '))

    return ((a**2)+ (b**2)+(c**2) + 2*a*b + 2*a*c+ 2*b*c)

#7.

def broj_litara_Marko():

    a = int(input('Broj sati:'))
    b =  a*0.5
    print(math.floor(b))

#8.

def duzina_trake_za_ivicu():

    P =int(input('Povrsina:'))

    r = math.sqrt(P/(math.pi))

    duzina_trake = r * 2 * math.pi

    return duzina_trake


#9.

def duzina_ograde_u_metrima():

    d = int(input('Unesite d: '))
    s = int(input('Unesite s: '))
    r = int(input('Unesite r: '))


    return 2*r*(d+s)

#10.

def povrsina_zida():

    x1 = int(input('Unesite x1: '))
    y1 = int(input('Unesite y1: '))
    x2 = int(input('Unesite x2: '))
    y2 = int(input('Unesite y2: '))

    return ((x2-x1) * (y1-y2)), (2 * ((x2-x1)+(y1-y2)))


#11.

def euclide_distance(x_cords, y_cords):

    #x_cords = (x1,x2) and y_cords = (y1,y2)

    return math.sqrt(((x_cords[1]-x_cords[0])**2) +((y_cords[1]-y_cords[0])**2))

# 12.

def koliko_godina_ima_Milos():

    N = int(input('Unesite broj godina: '))

    return (2024 - N)

# 13.

def kordinate_blaga():
    x1 = int(input('Unesite x1: '))
    y1 = int(input('Unesite y1: '))
    x2 = int(input('Unesite x2: '))
    y2 = int(input('Unesite y2: '))

    G = (x1, y1)
    K = (x2,y2)

    kordinate_blaga = (x2+2, y2-3)
    vazdusno_rastojanje = math.sqrt(((kordinate_blaga[0]-G[0])**2) +((kordinate_blaga[1]-G[1])**2))
    rastojanje_sa_obilaskom_kuce =math.sqrt(((K[0]-G[0])**2) +((K[1]-G[1])**2))  + math.sqrt(((kordinate_blaga[0]-K[0])**2) +((kordinate_blaga[1]-K[0])**2))

    return  kordinate_blaga, vazdusno_rastojanje, rastojanje_sa_obilaskom_kuce

#14.

# def procjena_cijene_stana():
#Ne razumijem zadatak

#15.

def povrsina_trougla():
    x1 = int(input('Unesite x1: '))
    y1 = int(input('Unesite y1: '))
    x2 = int(input('Unesite x2: '))
    y2 = int(input('Unesite y2: '))
    x3 = int(input('Unesite x3: '))
    y3 = int(input('Unesite y3: '))

    A=(x1,y1)
    B=(x2,y2)
    C=(x3,y3)

    a = math.sqrt(((A[0]-B[0])**2) +((A[1]-B[1])**2))
    b = math.sqrt(((B[0]-C[0])**2) +((B[1]-C[1])**2))
    c = math.sqrt(((C[0]-A[0])**2) +((C[1]-A[1])**2))

    s = (a+b+c)/2

    return math.sqrt(s*(s-a)*(s-b)*(s-c))


#16.

def cijena_voznje():
    km = int(input('Unesite broj km: '))

    return km *0.5 +1


#17.

def bukvarnica():

    cijena = int(input('Unesite cijenu: '))
    popust = int(input('Unesite popust: '))

    return cijena * (popust/100)

#18.

def cijena_play_station_5():

    pocetna_cijena = int(input('Unesite cijenu: '))

    a = pocetna_cijena + (pocetna_cijena* 0.1)
    b = a - (a*0.1)

    return b

#19.

def zbir_cifara_trocifrenog_broja():
    sum = 0
    trocifreni_broj = input('Unesite trocifreni broj:')

    for _ in trocifreni_broj:

        sum = sum + int(_)


    return sum


#20.
def desifrovanje_koda():

    sum = 0
    proizvod = 1

    trocifreni_broj = input('Unesite trocifreni broj:')

    for _ in trocifreni_broj:
        sum = sum + int(_)
        proizvod = proizvod * int(_)

    return proizvod-sum

#21.

def tajna_o_nastaku_univerzuma():

    cb = input('Unesite cetvorocifreni broj:')
    cb_len = len(cb)
    a = int(cb[0])
    d = int(cb[cb_len-1])
    b = int(cb[1])
    c = int(cb[2])
    return(((a+d)**2) - ((b-d)**2))

#22.

def prosjecan_broj_ucenika():
    N = int(input('Broj N: '))
    K = int(input('Broj K: '))
    p1 = float(input('p1: '))
    p2 = float(input('p2: '))

    prosjecan_broj_peona = (N * p1 + K * p2) / (N + K)

    return prosjecan_broj_peona



#23.

def vraca_srednju_vrijednost():
    a = int(input('Parametar a: '))
    b = int(input('Parametar b: '))

    if a > b:

        p = a - b
        s = b + p/2
    else:
        p = b - a
        s = a + p / 2

    return  s

#24.

def mijenja_vrijednost_x_y():
    x = int(input('Parametar x: '))
    y = int(input('Parametar y: '))

    a = y
    y = x
    x = a

    return x, y

#25.
def broj_cijelih_metara():

 broj_centimetara = int(input('Broj centimetara: '))

 m = math.floor(broj_centimetara * 0.01)

 return m

#26.

def sprat():
    cb = input('Unesite cetvorocifreni broj:')

    return cb[-2]

#27.
def kvadrat_zbirca_cifara():

    cb = input('Unesite cetvorocifreni broj:')

    sum = 0

    for _ in cb:

        sum = sum + int(_)

    return  sum**2

#28.
def zamjena_prve_i_poslednje_cifre():

    trocifreni_broj = input('Unesite trocifreni broj:')
    a = trocifreni_broj[0]
    trocifreni_broj[0] = trocifreni_broj[-1]
    trocifreni_broj[-1] = a

    return  trocifreni_broj

#29.
def lokacija_na_sredini_puta():
    x1 = int(input('Unesite x1: '))
    y1 = int(input('Unesite y1: '))
    x2 = int(input('Unesite x2: '))
    y2 = int(input('Unesite y2: '))

    A = (x1, y1)
    B = (x2, y2)

    rastojanje = (math.sqrt(((A[0]-B[0])**2) +((A[1]-B[1])**2)))/2

    C = ((A[0]+B[0])/2,(A[1]+B[1])/2)

    return C, rastojanje

#30.
def broj_kvadrata():

    P = 543*130
    P_kvadrata = 64*64

    broj_kvadata = math.floor(P/P_kvadrata)

    return  broj_kvadata

#31.

def povrsina_ekrana():

    d = 50

    b = math.sqrt((d**2)/(((16/9)**2)+1))
    a = (16/9)*b

    return  a*b

#32.
def sestocifreni_broj_boolean():

    sb = input('Sestocifreni broj: ')

    a =sb[0]
    b =sb[1]
    c =sb[2]
    d =sb[3]
    e =sb[4]
    f =sb[5]

    return a*c + 2 + f == b + d *e

#33.

def broj_poligona_na_poljani():

    a = int(input('Stranica poligona: '))
    d = int(input('Duzina poljane'))
    s = int(input('Sirina poljane'))

    return math.floor((d*s)/(a**2))

#34.

def specijalni_identifikacioni_broj():
    sb = input('Sestocifreni broj: ')

    sum = 0

    for _ in sb:

        sum = sum + int(_)

    s = sum**2 - (sb[2]*sb[3])

    print(s)

#35.

def sifra():

    pb = input('Petocifreni broj: ')

    s = pb[2] +pb[-1]

    return s